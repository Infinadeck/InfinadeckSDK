// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "InfinadeckSDK.h"
#include "InfinadeckBlueprintBPLibrary.generated.h"
/* 
*	Function library class.
*	Each function in it is expected to be static and represents blueprint node that can be called in any blueprint.
*
*	When declaring function you can define metadata for the node. Key function specifiers will be BlueprintPure and BlueprintCallable.
*	BlueprintPure - means the function does not affect the owning object in any way and thus creates a node without Exec pins.
*	BlueprintCallable - makes a function which can be executed in Blueprints - Thus it has Exec pins.
*	DisplayName - full name of the node, shown when you mouse over the node and in the blueprint drop down menu.
*				Its lets you name the node using characters not allowed in C++ function names.
*	CompactNodeTitle - the word(s) that appear on the node.
*	Keywords -	the list of keywords that helps you to find node when you search for it using Blueprint drop-down menu. 
*				Good example is "Print String" node which you can find also by using keyword "log".
*	Category -	the category your node will be under in the Blueprint drop-down menu.
*
*	For more info on custom blueprint nodes visit documentation:
*	https://wiki.unrealengine.com/Custom_Blueprint_Node_Creation
*/
UCLASS()
class UInfinadeckBlueprintBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get X and Y Movement Data from Treadmill", Keywords = "Infinadeck Treadmill Locomotion Movement Omnidirectional"), Category = "Infinadeck")
	static FVector GetTreadmillMotion();

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get position of treadmill ring", Keywords = "Infinadeck Treadmill Locomotion Ring Omnidirectional"), Category = "Infinadeck")
	static FVector GetRingPosition();

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get radius of treadmill ring", Keywords = "Infinadeck Treadmill Locomotion Ring Radius Omnidirectional"), Category = "Infinadeck")
	static float GetRingRadius();

  	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Check if treadmill is running", Keywords = "Infinadeck Treadmill Control VR Locomotion Omnidirectional"), Category = "Infinadeck")
  	static bool GetTreadmillRunState();

  	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Set treadmill to run", Keywords = "Infinadeck Treadmill Locomotion Control VR Omnidirectional"), Category = "Infinadeck")
  	static void SetTreadmillRunState(bool state);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Pause treadmill motion", Keywords = "Infinadeck Treadmill Locomotion Control VR Omnidirectional"), Category = "Infinadeck")
  	static void SetTreadmillBrake(bool brake);
};
