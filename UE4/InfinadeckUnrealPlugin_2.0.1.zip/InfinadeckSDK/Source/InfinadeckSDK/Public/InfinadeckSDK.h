// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

class FInfinadeckSDKModule : public IModuleInterface
{
public:

	inline FVector GetRingPosition();
	inline FVector GetTreadmillDirection();
	inline float GetRingRadius();
	inline void SetTreadmillRunState(bool state);
	inline void SetBrake(bool brake);
  	inline bool GetTreadmillRunState();
	inline void ConnectToTreadmill();
	inline bool CheckConnection();
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;


	static inline FInfinadeckSDKModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FInfinadeckSDKModule>("InfinadeckSDK");
	}

private:
	/** Handle to the test dll we will load */
	void*	ExampleLibraryHandle;
	bool run_once_ = false;
};