// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.IO;
using System;

public class InfinadeckSDK : ModuleRules
{
    private string ModulePath
    {
        get { return ModuleDirectory; }
    }

    private string ThirdPartyPath
    {
        get { return Path.GetFullPath(Path.Combine(ModulePath, "../../ThirdParty/")); }
    }

    private string BinariesPath
    {
        get { return Path.GetFullPath(Path.Combine(ModulePath, "../../Binaries/")); }
    }

    public InfinadeckSDK(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] {
				"InfinadeckSDK/Public"
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				"InfinadeckSDK/Private",
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
                "CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				"Core",
				"Projects"
				// ... add other public dependencies that you statically link with here ...
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				// ... add private dependencies that you statically link with here ...	
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);

        if (!LoadInfinadeckLib(Target))
        {
            Console.WriteLine("Platform not supported!");
        }

        if (Target.Platform == UnrealTargetPlatform.Win32 || Target.Platform == UnrealTargetPlatform.Win64)
        {
            // OVRPlugin
            {
                PublicDelayLoadDLLs.Add("InfinadeckAPI.dll");
                RuntimeDependencies.Add("$(EngineDir)/Binaries/ThirdParty/Infinadeck/InfinadeckPlugin/InfinadeckAPI/" + Target.Platform.ToString() + "/InfinadeckAPI.dll");
            }
        }
    }

    public bool LoadInfinadeckLib(ReadOnlyTargetRules Target)
    {
        bool isLibrarySupported = false;

        if ((Target.Platform == UnrealTargetPlatform.Win64) || (Target.Platform == UnrealTargetPlatform.Win32))
        {
            isLibrarySupported = true;

            string PlatformString = (Target.Platform == UnrealTargetPlatform.Win64) ? "Win64" : "Win32";
            string LibrariesPath = Path.Combine(ThirdPartyPath, "Infinadeck", "lib");
            string fullLibPath = Path.Combine(LibrariesPath, PlatformString, "InfinadeckAPI.lib");
            PublicAdditionalLibraries.Add(fullLibPath);

        }
        else if (Target.Platform == UnrealTargetPlatform.Mac)
        {

            isLibrarySupported = false;


        }

        if (isLibrarySupported)
        {
            var incl = Path.Combine(ThirdPartyPath, "Infinadeck", "include");
            Console.WriteLine("Adding the include path: " + incl);
            PublicIncludePaths.Add(incl);
        }

        return isLibrarySupported;
    }
}
