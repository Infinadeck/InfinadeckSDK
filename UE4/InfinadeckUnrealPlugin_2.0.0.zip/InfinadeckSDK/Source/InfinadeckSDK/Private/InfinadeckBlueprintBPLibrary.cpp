  // Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#include "InfinadeckBlueprintBPLibrary.h"

UInfinadeckBlueprintBPLibrary::UInfinadeckBlueprintBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

FVector UInfinadeckBlueprintBPLibrary::GetTreadmillMotion() {
  if (!FInfinadeckSDKModule::Get().CheckConnection()) {
    FInfinadeckSDKModule::Get().ConnectToTreadmill();
  }
  return FInfinadeckSDKModule::Get().GetTreadmillDirection();
}

FVector UInfinadeckBlueprintBPLibrary::GetRingPosition() {
  if (!FInfinadeckSDKModule::Get().CheckConnection()) {
    FInfinadeckSDKModule::Get().ConnectToTreadmill();
  }
  return FInfinadeckSDKModule::Get().GetRingPosition();
}

float UInfinadeckBlueprintBPLibrary::GetRingRadius() {
  if (!FInfinadeckSDKModule::Get().CheckConnection()) {
    FInfinadeckSDKModule::Get().ConnectToTreadmill();
  }
  return FInfinadeckSDKModule::Get().GetRingRadius();
}

bool UInfinadeckBlueprintBPLibrary::GetTreadmillRunState() {
  if (!FInfinadeckSDKModule::Get().CheckConnection()) {
    FInfinadeckSDKModule::Get().ConnectToTreadmill();
  }
  return FInfinadeckSDKModule::Get().GetTreadmillRunState();
}

void UInfinadeckBlueprintBPLibrary::SetTreadmillRunState(bool state) {
  if (!FInfinadeckSDKModule::Get().CheckConnection()) {
    FInfinadeckSDKModule::Get().ConnectToTreadmill();
  }
  FInfinadeckSDKModule::Get().SetTreadmillRunState(state);
}

void UInfinadeckBlueprintBPLibrary::SetTreadmillBrake(bool brake) {

}


